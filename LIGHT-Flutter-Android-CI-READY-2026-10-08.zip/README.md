# LIGHT — Flutter Android natif

Migration native de LIGHT depuis le prototype React/TypeScript.

## Architecture

- Flutter/Dart natif, aucun WebView, Capacitor ou PWA.
- Android natif avec Kotlin et Android Gradle Plugin.
- `lib/models/pressing.dart` reproduit le modèle Firestore du prototype.
- `lib/services/firebase_service.dart` est l'unique porte d'entrée Firestore.
- `lib/views/home_view.dart` contient l'accueil.
- `lib/views/pressing_detail_view.dart` contient la fiche pressing et la commande.
- Données démo conservées pour permettre le lancement sans configuration Firebase.

## Configuration Android CI

- Java 17
- Android compileSdk 34
- Android minSdk 26
- Android targetSdk 34
- Android Gradle Plugin 8.6.1
- Kotlin 2.1.0
- Gradle 8.7
- Flutter 3.29.3

Le workflow GitHub Actions installe explicitement Java, Flutter et Gradle. `android/gradlew` est un lanceur CI qui délègue à la version Gradle installée par le workflow ; cela évite de dépendre d'un binaire Gradle Wrapper absent du dépôt.

## Firebase Android

La compilation de l'APK ne nécessite pas de credentials Firebase. Pour connecter une vraie base Firebase, ajoutez le fichier `android/app/google-services.json` correspondant à l'application Android `com.light.app` et activez le plugin Google Services dans Gradle avec la méthode officielle correspondant à votre projet Firebase.

Le modèle Firestore attendu est :

- `pressings/{id}`
- `pressings/{id}/services/{id}`
- `pressings/{id}/deliveryZones/{id}`
- `pressings/{id}/orders/{id}`

## CI/CD

`.github/workflows/build-android.yml` :

1. installe Java 17 ;
2. installe Flutter 3.29.3 ;
3. installe Gradle 8.7 ;
4. restaure les dépendances ;
5. exécute `flutter analyze` ;
6. exécute `flutter test` ;
7. exécute `flutter build apk --release` ;
8. publie `app-release.apk` comme artefact GitHub Actions.
