package com.light.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
