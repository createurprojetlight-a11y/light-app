@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo Gradle n'est pas installe. Utilisez Android Studio/Flutter ou le workflow GitHub Actions de ce projet.
  exit /b 1
)
gradle %*
