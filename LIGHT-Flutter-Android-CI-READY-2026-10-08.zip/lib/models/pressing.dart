import 'package:cloud_firestore/cloud_firestore.dart';

enum PricingType { perItem, perKg, both }

enum SubscriptionStatus { none, trial, active, grace, expired, suspended }

enum WeekDay { monday, tuesday, wednesday, thursday, friday, saturday, sunday }

class OpeningHoursEntry {
  final String open;
  final String close;

  const OpeningHoursEntry({required this.open, required this.close});

  factory OpeningHoursEntry.fromMap(Map<String, dynamic> map) {
    return OpeningHoursEntry(
      open: map['open']?.toString() ?? '00:00',
      close: map['close']?.toString() ?? '00:00',
    );
  }
}

typedef OpeningHours = Map<WeekDay, OpeningHoursEntry?>;

class Coordinates {
  final double lat;
  final double lng;

  const Coordinates({required this.lat, required this.lng});

  factory Coordinates.fromFirestore(dynamic value) {
    if (value is GeoPoint) {
      return Coordinates(lat: value.latitude, lng: value.longitude);
    }
    if (value is Map) {
      return Coordinates(
        lat: _toDouble(value['lat'] ?? value['latitude']),
        lng: _toDouble(value['lng'] ?? value['longitude']),
      );
    }
    return const Coordinates(lat: 0, lng: 0);
  }
}

class PressingService {
  final String id;
  final String name;
  final String category;
  final PricingType pricingType;
  final double? pricePerItem;
  final double? pricePerKg;
  final double? minKg;
  final double? maxKg;
  final String? description;

  const PressingService({
    required this.id,
    required this.name,
    required this.category,
    required this.pricingType,
    this.pricePerItem,
    this.pricePerKg,
    this.minKg,
    this.maxKg,
    this.description,
  });

  factory PressingService.fromMap(String id, Map<String, dynamic> map) {
    return PressingService(
      id: id,
      name: map['name']?.toString() ?? '',
      category: map['category']?.toString() ?? 'Autres',
      pricingType: pricingTypeFromString(map['pricingType']?.toString()),
      pricePerItem: _toNullableDouble(map['pricePerItem']),
      pricePerKg: _toNullableDouble(map['pricePerKg']),
      minKg: _toNullableDouble(map['minKg']),
      maxKg: _toNullableDouble(map['maxKg']),
      description: map['description']?.toString(),
    );
  }
}

class DeliveryZone {
  final String id;
  final String name;
  final double fee;
  final String estimatedTime;

  const DeliveryZone({
    required this.id,
    required this.name,
    required this.fee,
    required this.estimatedTime,
  });

  factory DeliveryZone.fromMap(String id, Map<String, dynamic> map) {
    return DeliveryZone(
      id: id,
      name: map['name']?.toString() ?? '',
      fee: _toDouble(map['fee']),
      estimatedTime: map['estimatedTime']?.toString() ?? '',
    );
  }
}

class Pressing {
  final String id;
  final String slug;
  final String name;
  final String description;
  final String? logoUrl;
  final String? coverUrl;
  final String phone;
  final String whatsapp;
  final String address;
  final String city;
  final String neighborhood;
  final Coordinates coordinates;
  final OpeningHours openingHours;
  final bool isAvailable;
  final SubscriptionStatus activeSubscription;
  final List<String> paymentMethods;

  const Pressing({
    required this.id,
    required this.slug,
    required this.name,
    required this.description,
    this.logoUrl,
    this.coverUrl,
    required this.phone,
    required this.whatsapp,
    required this.address,
    required this.city,
    required this.neighborhood,
    required this.coordinates,
    required this.openingHours,
    required this.isAvailable,
    required this.activeSubscription,
    this.paymentMethods = const [],
  });

  factory Pressing.fromMap(String id, Map<String, dynamic> map) {
    return Pressing(
      id: id,
      slug: map['slug']?.toString() ?? '',
      name: map['name']?.toString() ?? '',
      description: map['description']?.toString() ?? '',
      logoUrl: map['logoUrl']?.toString(),
      coverUrl: map['coverUrl']?.toString(),
      phone: map['phone']?.toString() ?? '',
      whatsapp: map['whatsapp']?.toString() ?? '',
      address: map['address']?.toString() ?? '',
      city: map['city']?.toString() ?? '',
      neighborhood: map['neighborhood']?.toString() ?? '',
      coordinates: Coordinates.fromFirestore(map['coordinates']),
      openingHours: openingHoursFromMap(map['openingHours']),
      isAvailable: map['isAvailable'] == true,
      activeSubscription: subscriptionStatusFromString(map['activeSubscription']?.toString()),
      paymentMethods: (map['paymentMethods'] is Iterable)
          ? List<String>.from((map['paymentMethods'] as Iterable).map((e) => e.toString()))
          : const [],
    );
  }
}

class PressingWithRelations extends Pressing {
  final List<PressingService> services;
  final List<DeliveryZone> deliveryZones;

  const PressingWithRelations({
    required super.id,
    required super.slug,
    required super.name,
    required super.description,
    super.logoUrl,
    super.coverUrl,
    required super.phone,
    required super.whatsapp,
    required super.address,
    required super.city,
    required super.neighborhood,
    required super.coordinates,
    required super.openingHours,
    required super.isAvailable,
    required super.activeSubscription,
    super.paymentMethods,
    this.services = const [],
    this.deliveryZones = const [],
  });

  factory PressingWithRelations.fromPressing(
    Pressing pressing, {
    required List<PressingService> services,
    required List<DeliveryZone> deliveryZones,
  }) {
    return PressingWithRelations(
      id: pressing.id,
      slug: pressing.slug,
      name: pressing.name,
      description: pressing.description,
      logoUrl: pressing.logoUrl,
      coverUrl: pressing.coverUrl,
      phone: pressing.phone,
      whatsapp: pressing.whatsapp,
      address: pressing.address,
      city: pressing.city,
      neighborhood: pressing.neighborhood,
      coordinates: pressing.coordinates,
      openingHours: pressing.openingHours,
      isAvailable: pressing.isAvailable,
      activeSubscription: pressing.activeSubscription,
      paymentMethods: pressing.paymentMethods,
      services: services,
      deliveryZones: deliveryZones,
    );
  }
}

bool isPressingAcceptingOrders(Pressing p) {
  return p.isAvailable &&
      (p.activeSubscription == SubscriptionStatus.active ||
          p.activeSubscription == SubscriptionStatus.trial);
}

PricingType pricingTypeFromString(String? value) {
  switch (value) {
    case 'per_item':
      return PricingType.perItem;
    case 'per_kg':
      return PricingType.perKg;
    case 'both':
      return PricingType.both;
    default:
      return PricingType.perItem;
  }
}

SubscriptionStatus subscriptionStatusFromString(String? value) {
  switch (value) {
    case 'trial':
      return SubscriptionStatus.trial;
    case 'active':
      return SubscriptionStatus.active;
    case 'grace':
      return SubscriptionStatus.grace;
    case 'expired':
      return SubscriptionStatus.expired;
    case 'suspended':
      return SubscriptionStatus.suspended;
    default:
      return SubscriptionStatus.none;
  }
}

WeekDay weekDayFromString(String value) {
  return WeekDay.values.firstWhere(
    (day) => day.name == value,
    orElse: () => WeekDay.monday,
  );
}

OpeningHours openingHoursFromMap(dynamic value) {
  final result = <WeekDay, OpeningHoursEntry?>{};
  if (value is Map) {
    for (final day in WeekDay.values) {
      final raw = value[day.name];
      result[day] = raw is Map
          ? OpeningHoursEntry.fromMap(Map<String, dynamic>.from(raw))
          : null;
    }
  } else {
    for (final day in WeekDay.values) {
      result[day] = null;
    }
  }
  return result;
}

double _toDouble(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse(value?.toString() ?? '') ?? 0;
}

double? _toNullableDouble(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  return double.tryParse(value.toString());
}
