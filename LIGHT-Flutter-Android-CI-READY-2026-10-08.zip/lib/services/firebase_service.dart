import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../models/pressing.dart';

class FirebaseService {
  FirebaseService._();

  static final FirebaseService instance = FirebaseService._();

  FirebaseFirestore get _firestore => FirebaseFirestore.instance;

  bool get isConfigured => Firebase.apps.isNotEmpty;

  User? get currentUser => FirebaseAuth.instance.currentUser;

  Future<PressingWithRelations?> getPressingBySlug(String slug) async {
    if (!isConfigured) return findDemoPressing(slug);

    final snapshot = await _firestore
        .collection('pressings')
        .where('slug', isEqualTo: slug)
        .limit(1)
        .get();

    if (snapshot.docs.isEmpty) return null;

    final document = snapshot.docs.first;
    final pressing = Pressing.fromMap(document.id, document.data());

    final results = await Future.wait([
      _firestore.collection('pressings').doc(document.id).collection('services').get(),
      _firestore.collection('pressings').doc(document.id).collection('deliveryZones').get(),
    ]);

    final services = results[0].docs
        .map((doc) => PressingService.fromMap(doc.id, doc.data()))
        .toList();
    final zones = results[1].docs
        .map((doc) => DeliveryZone.fromMap(doc.id, doc.data()))
        .toList();

    return PressingWithRelations.fromPressing(
      pressing,
      services: services,
      deliveryZones: zones,
    );
  }

  Future<List<PressingWithRelations>> listPressings() async {
    if (!isConfigured) return demoPressings;

    final snapshot = await _firestore.collection('pressings').get();
    final results = await Future.wait(
      snapshot.docs.map((document) async {
        final pressing = Pressing.fromMap(document.id, document.data());
        final servicesFuture = _firestore
            .collection('pressings')
            .doc(document.id)
            .collection('services')
            .get();
        final zonesFuture = _firestore
            .collection('pressings')
            .doc(document.id)
            .collection('deliveryZones')
            .get();
        final values = await Future.wait([servicesFuture, zonesFuture]);
        return PressingWithRelations.fromPressing(
          pressing,
          services: values[0].docs
              .map((doc) => PressingService.fromMap(doc.id, doc.data()))
              .toList(),
          deliveryZones: values[1].docs
              .map((doc) => DeliveryZone.fromMap(doc.id, doc.data()))
              .toList(),
        );
      }),
    );
    return results;
  }

  Future<void> submitOrder({
    required PressingWithRelations pressing,
    required String customerName,
    required String phone,
    required List<OrderLine> lines,
    String? deliveryZoneId,
  }) async {
    if (!isConfigured) return;

    DeliveryZone? zone;
    if (deliveryZoneId != null) {
      for (final candidate in pressing.deliveryZones) {
        if (candidate.id == deliveryZoneId) {
          zone = candidate;
          break;
        }
      }
    }

    await _firestore.collection('pressings').doc(pressing.id).collection('orders').add({
      'customerName': customerName.trim(),
      'phone': phone.trim(),
      'lines': lines.map((line) => line.toMap()).toList(),
      'deliveryZoneId': deliveryZoneId,
      'deliveryFee': zone?.fee ?? 0,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}

class OrderLine {
  final String serviceId;
  final String serviceName;
  final String mode;
  final double quantity;
  final double unitPrice;

  const OrderLine({
    required this.serviceId,
    required this.serviceName,
    required this.mode,
    required this.quantity,
    required this.unitPrice,
  });

  Map<String, dynamic> toMap() => {
        'serviceId': serviceId,
        'serviceName': serviceName,
        'mode': mode,
        'quantity': quantity,
        'unitPrice': unitPrice,
      };
}

final _openWeek = <WeekDay, OpeningHoursEntry?>{
  WeekDay.monday: const OpeningHoursEntry(open: '07:30', close: '19:00'),
  WeekDay.tuesday: const OpeningHoursEntry(open: '07:30', close: '19:00'),
  WeekDay.wednesday: const OpeningHoursEntry(open: '07:30', close: '19:00'),
  WeekDay.thursday: const OpeningHoursEntry(open: '07:30', close: '19:00'),
  WeekDay.friday: const OpeningHoursEntry(open: '07:30', close: '19:00'),
  WeekDay.saturday: const OpeningHoursEntry(open: '08:00', close: '17:00'),
  WeekDay.sunday: null,
};

final demoPressings = <PressingWithRelations>[
  PressingWithRelations(
    id: 'demo-pressing-akwa',
    slug: 'demo-pressing-akwa',
    name: 'Pressing Démo Akwa',
    description: 'Nettoyage à sec, repassage et linge au kilo. Retrait sur place ou livraison dans le quartier.',
    phone: '+237600000000',
    whatsapp: '237600000000',
    address: 'Rue de démonstration',
    city: 'Douala',
    neighborhood: 'Akwa',
    coordinates: const Coordinates(lat: 4.0435, lng: 9.7679),
    openingHours: _openWeek,
    isAvailable: true,
    activeSubscription: SubscriptionStatus.active,
    paymentMethods: ['Espèces', 'Mobile Money'],
    services: [
      PressingService(id: 'chemise', name: 'Chemise', category: 'Vêtements', pricingType: PricingType.perItem, pricePerItem: 500),
      PressingService(id: 'pantalon', name: 'Pantalon', category: 'Vêtements', pricingType: PricingType.perItem, pricePerItem: 700),
      PressingService(id: 'robe', name: 'Robe', category: 'Vêtements', pricingType: PricingType.perItem, pricePerItem: 1500),
      PressingService(id: 'costume', name: 'Costume 2 pièces', category: 'Vêtements', pricingType: PricingType.perItem, pricePerItem: 2500),
      PressingService(id: 'kilo', name: 'Linge au kilo', category: 'Linge', pricingType: PricingType.perKg, pricePerKg: 1000, minKg: 3, maxKg: 20, description: 'Tout textile courant, trié à la dépose.'),
      PressingService(id: 'rideaux', name: 'Rideaux et nappes', category: 'Linge de maison', pricingType: PricingType.both, pricePerItem: 2000, pricePerKg: 900, minKg: 2, maxKg: 15, description: 'Au choix : à la pièce ou au kilo.'),
      PressingService(id: 'couette', name: 'Couette', category: 'Linge de maison', pricingType: PricingType.perItem, pricePerItem: 3000),
    ],
    deliveryZones: [
      DeliveryZone(id: 'akwa', name: 'Akwa', fee: 1000, estimatedTime: '30 – 60 min'),
      DeliveryZone(id: 'bonanjo', name: 'Bonanjo', fee: 1500, estimatedTime: '45 – 75 min'),
      DeliveryZone(id: 'bonapriso', name: 'Bonapriso', fee: 1200, estimatedTime: '40 – 70 min'),
    ],
  ),
  PressingWithRelations(
    id: 'demo-pressing-bonapriso',
    slug: 'demo-pressing-bonapriso',
    name: 'Pressing Démo Bonapriso',
    description: 'Pressing de démonstration fermé, pour tester l’état « indisponible ».',
    phone: '+237600000001',
    whatsapp: '237600000001',
    address: 'Rue de démonstration',
    city: 'Douala',
    neighborhood: 'Bonapriso',
    coordinates: const Coordinates(lat: 4.036, lng: 9.698),
    openingHours: _openWeek,
    isAvailable: false,
    activeSubscription: SubscriptionStatus.expired,
    paymentMethods: ['Espèces'],
  ),
];

PressingWithRelations? findDemoPressing(String slug) {
  for (final pressing in demoPressings) {
    if (pressing.slug == slug) return pressing;
  }
  return null;
}
