import '../models/pressing.dart';

class PricingService {
  static int round(double value) => value.round();

  static int computePiece({required double qty, required double itemPrice}) {
    if (qty % 1 != 0 || qty < 1) throw const FormatException('INVALID_QTY');
    return qty.toInt() * round(itemPrice);
  }

  static int computeKg({
    required double weightKg,
    required double pricePerKg,
    double? minWeightKg,
    double? maxWeightKg,
  }) {
    if (!(weightKg > 0)) throw const FormatException('INVALID_WEIGHT');
    if (maxWeightKg != null && weightKg > maxWeightKg) {
      throw const FormatException('WEIGHT_ABOVE_MAX');
    }
    final billable = weightKg < (minWeightKg ?? 0) ? (minWeightKg ?? 0) : weightKg;
    return round(billable * pricePerKg);
  }

  static String formatXaf(num value) {
    final digits = value.round().toString();
    final buffer = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(' ');
      buffer.write(digits[i]);
    }
    return '${buffer.toString()} FCFA';
  }

  static String servicePriceLabel(PressingService service) {
    final parts = <String>[];
    if (service.pricePerItem != null) {
      parts.add('${formatXaf(service.pricePerItem!)} / pièce');
    }
    if (service.pricePerKg != null) {
      final min = service.minKg == null ? '' : ' · min ${service.minKg!.toStringAsFixed(service.minKg! % 1 == 0 ? 0 : 1)} kg';
      final max = service.maxKg == null ? '' : ' · max ${service.maxKg!.toStringAsFixed(service.maxKg! % 1 == 0 ? 0 : 1)} kg';
      parts.add('${formatXaf(service.pricePerKg!)} / kg$min$max');
    }
    return parts.join(' · ');
  }
}
