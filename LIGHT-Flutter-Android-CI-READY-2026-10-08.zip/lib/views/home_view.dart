import 'package:flutter/material.dart';

import '../models/pressing.dart';
import '../services/firebase_service.dart';
import 'pressing_detail_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late Future<List<PressingWithRelations>> _pressings;

  @override
  void initState() {
    super.initState();
    _pressings = FirebaseService.instance.listPressings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder<List<PressingWithRelations>>(
          future: _pressings,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Impossible de charger les pressings : ${snapshot.error}'));
            }
            final pressings = snapshot.data ?? const <PressingWithRelations>[];
            return RefreshIndicator(
              onRefresh: () async => setState(() => _pressings = FirebaseService.instance.listPressings()),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
                children: [
                  const Text('LIGHT', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 4)),
                  const SizedBox(height: 70),
                  const Text('Votre pressing,\nen pleine lumière.', style: TextStyle(fontSize: 42, height: 1.02, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 16),
                  Text('Services, prix et commande : tout en un seul lien.', style: TextStyle(fontSize: 18, color: Colors.grey.shade700)),
                  const SizedBox(height: 34),
                  for (final pressing in pressings) ...[
                    _PressingCard(pressing: pressing),
                    const SizedBox(height: 12),
                  ],
                  if (pressings.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 30),
                      child: Center(child: Text('Aucun pressing disponible.')),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _PressingCard extends StatelessWidget {
  final PressingWithRelations pressing;
  const _PressingCard({required this.pressing});

  @override
  Widget build(BuildContext context) {
    final available = isPressingAcceptingOrders(pressing);
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PressingDetailView(pressing: pressing))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: const Color(0xFFF4B942),
                backgroundImage: pressing.logoUrl != null ? NetworkImage(pressing.logoUrl!) : null,
                child: pressing.logoUrl == null ? Text((pressing.name.isEmpty ? '?' : pressing.name.substring(0, 1)), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)) : null,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(pressing.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  const SizedBox(height: 3),
                  Text('${pressing.neighborhood}, ${pressing.city}', style: TextStyle(color: Colors.grey.shade600)),
                  const SizedBox(height: 7),
                  Text(available ? 'Commandes ouvertes' : 'Indisponible', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: available ? Colors.green.shade700 : Colors.red.shade700)),
                ]),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}
