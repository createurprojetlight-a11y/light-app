import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/pressing.dart';
import '../services/firebase_service.dart';
import '../services/pricing_service.dart';

class PressingDetailView extends StatefulWidget {
  final PressingWithRelations pressing;
  const PressingDetailView({super.key, required this.pressing});

  @override
  State<PressingDetailView> createState() => _PressingDetailViewState();
}

class _PressingDetailViewState extends State<PressingDetailView> {
  bool favorite = false;

  @override
  Widget build(BuildContext context) {
    final p = widget.pressing;
    final unavailable = !isPressingAcceptingOrders(p);
    return Scaffold(
      appBar: AppBar(title: const Text('LIGHT'), actions: [IconButton(onPressed: () => setState(() => favorite = !favorite), icon: Icon(favorite ? Icons.favorite : Icons.favorite_border))]),
      body: unavailable ? _Unavailable(pressing: p) : _AvailablePressing(pressing: p),
    );
  }
}

class _Unavailable extends StatelessWidget {
  final PressingWithRelations pressing;
  const _Unavailable({required this.pressing});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          CircleAvatar(radius: 32, backgroundColor: const Color(0xFFF4B942), child: Text((pressing.name.isEmpty ? '?' : pressing.name.substring(0, 1)), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 24))),
          const SizedBox(height: 20),
          Text('${pressing.name} est actuellement indisponible', textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Text('Ce pressing ne prend pas de commandes pour le moment.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade700)),
          const SizedBox(height: 22),
          FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Trouver un autre pressing sur LIGHT')),
        ]),
      ),
    );
  }
}

class _AvailablePressing extends StatelessWidget {
  final PressingWithRelations pressing;
  const _AvailablePressing({required this.pressing});

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final categories = <String, List<PressingService>>{};
    for (final service in pressing.services) {
      categories.putIfAbsent(service.category, () => []).add(service);
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
          decoration: BoxDecoration(color: const Color(0xFF22211E), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 32, backgroundColor: const Color(0xFFF4B942), backgroundImage: pressing.logoUrl != null ? NetworkImage(pressing.logoUrl!) : null, child: pressing.logoUrl == null ? Text((pressing.name.isEmpty ? '?' : pressing.name.substring(0, 1)), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 24)) : null),
            const SizedBox(height: 16),
            Text(pressing.name, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text('${pressing.neighborhood}, ${pressing.city}', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            Text(pressing.description, style: const TextStyle(color: Colors.white70, height: 1.4)),
          ]),
        ),
        Wrap(spacing: 8, runSpacing: 8, children: [
          SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Scrollable.ensureVisible(context, alignment: 0.9), child: const Text('Commander'))),
          OutlinedButton.icon(onPressed: () => _open('tel:${pressing.phone}'), icon: const Icon(Icons.phone), label: const Text('Appeler')),
          OutlinedButton.icon(onPressed: () => _open('https://wa.me/${pressing.whatsapp}'), icon: const Icon(Icons.chat), label: const Text('WhatsApp')),
          OutlinedButton.icon(onPressed: () => _open('https://www.google.com/maps/search/?api=1&query=${pressing.coordinates.lat},${pressing.coordinates.lng}'), icon: const Icon(Icons.map), label: const Text('Carte')),
        ]),
        const SizedBox(height: 24),
        const Text('Services et prix', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        for (final entry in categories.entries) _ServiceCategory(category: entry.key, services: entry.value),
        const SizedBox(height: 10),
        _InfoCard(pressing: pressing),
        const SizedBox(height: 24),
        const Text('Commander sans compte', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        OrderForm(pressing: pressing),
      ],
    );
  }
}

class _ServiceCategory extends StatelessWidget {
  final String category;
  final List<PressingService> services;
  const _ServiceCategory({required this.category, required this.services});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 13, 16, 8), child: Text(category.toUpperCase(), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Colors.grey.shade600, letterSpacing: 1))),
        for (final service in services) ListTile(
          title: Text(service.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          subtitle: service.description == null ? null : Text(service.description!),
          trailing: Text(PricingService.servicePriceLabel(service), textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
        ),
      ]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final PressingWithRelations pressing;
  const _InfoCard({required this.pressing});

  @override
  Widget build(BuildContext context) {
    final hours = openingHoursRows(pressing.openingHours);
    return Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Informations', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
      const SizedBox(height: 12),
      Text('${pressing.address}, ${pressing.neighborhood}, ${pressing.city}'),
      const SizedBox(height: 10),
      const Text('Horaires', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      for (final row in hours) Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(row.label, style: TextStyle(color: Colors.grey.shade700)), Text(row.value, style: const TextStyle(fontWeight: FontWeight.w600))])),
      const SizedBox(height: 10),
      if (pressing.deliveryZones.isEmpty) const Text('Pas de livraison') else Text('Livraison : ${pressing.deliveryZones.map((z) => '${z.name} (${PricingService.formatXaf(z.fee)}, ${z.estimatedTime})').join(' · ')}'),
      if (pressing.paymentMethods.isNotEmpty) ...[const SizedBox(height: 8), Text('Paiement au pressing : ${pressing.paymentMethods.join(', ')}')],
    ])));
  }
}

class OrderForm extends StatefulWidget {
  final PressingWithRelations pressing;
  const OrderForm({super.key, required this.pressing});

  @override
  State<OrderForm> createState() => _OrderFormState();
}

class _OrderFormState extends State<OrderForm> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final Map<String, TextEditingController> _qty = {};
  final Map<String, TextEditingController> _kg = {};
  String? _zoneId;
  String? _message;
  List<String> _errors = [];
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    for (final service in widget.pressing.services) {
      _qty[service.id] = TextEditingController();
      _kg[service.id] = TextEditingController();
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    for (final c in _qty.values) c.dispose();
    for (final c in _kg.values) c.dispose();
    super.dispose();
  }

  String _normalizePhone(String value) => value.replaceAll(RegExp(r'\s'), '');

  Future<void> _submit() async {
    final errors = <String>[];
    final lines = <OrderLine>[];
    if (_name.text.trim().length < 2) errors.add('Indiquez votre nom.');
    final phone = _normalizePhone(_phone.text);
    if (!RegExp(r'^[26]\d{8}$').hasMatch(phone)) errors.add('Numéro invalide : 9 chiffres, par exemple 6XX XX XX XX.');

    for (final service in widget.pressing.services) {
      final itemRaw = _qty[service.id]!.text.trim().replaceAll(',', '.');
      final kgRaw = _kg[service.id]!.text.trim().replaceAll(',', '.');
      final item = double.tryParse(itemRaw) ?? 0;
      final kg = double.tryParse(kgRaw) ?? 0;
      final wantsItem = service.pricingType != PricingType.perKg;
      final wantsKg = service.pricingType != PricingType.perItem;
      if (item > 0 && kg > 0) {
        errors.add('${service.name} : choisissez les pièces ou les kilos, pas les deux.');
        continue;
      }
      if (item > 0) {
        if (!wantsItem || service.pricePerItem == null) errors.add('${service.name} : vente à la pièce indisponible.');
        else if (item % 1 != 0 || item < 1) errors.add('${service.name} : quantité invalide.');
        else lines.add(OrderLine(serviceId: service.id, serviceName: service.name, mode: 'PIECE', quantity: item, unitPrice: service.pricePerItem!));
      }
      if (kg > 0) {
        if (!wantsKg || service.pricePerKg == null) errors.add('${service.name} : vente au kilo indisponible.');
        else if (service.maxKg != null && kg > service.maxKg!) errors.add('${service.name} : maximum ${service.maxKg} kg.');
        else if (kg <= 0) errors.add('${service.name} : poids invalide.');
        else lines.add(OrderLine(serviceId: service.id, serviceName: service.name, mode: 'KG', quantity: kg, unitPrice: service.pricePerKg!));
      }
    }
    if (lines.isEmpty) errors.add('Choisissez au moins un service.');
    setState(() => _errors = errors);
    if (errors.isNotEmpty) return;

    setState(() {
      _sending = true;
      _message = null;
    });
    try {
      await FirebaseService.instance.submitOrder(
        pressing: widget.pressing,
        customerName: _name.text,
        phone: phone,
        lines: lines,
        deliveryZoneId: _zoneId,
      );
      if (!mounted) return;
      setState(() => _message = FirebaseService.instance.isConfigured ? 'Commande envoyée avec succès.' : 'Maquette : la commande n’est pas encore envoyée. Configurez Firebase pour activer l’envoi réel.');
    } catch (e) {
      if (!mounted) return;
      setState(() => _errors = ['Impossible d’envoyer la commande : $e']);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  int? _estimate() {
    var total = 0;
    var hasLine = false;
    for (final service in widget.pressing.services) {
      final item = double.tryParse(_qty[service.id]!.text.replaceAll(',', '.')) ?? 0;
      final kg = double.tryParse(_kg[service.id]!.text.replaceAll(',', '.')) ?? 0;
      if (item > 0 && kg > 0) return null;
      if (item > 0 && service.pricePerItem != null && item % 1 == 0) {
        total += PricingService.computePiece(qty: item, itemPrice: service.pricePerItem!);
        hasLine = true;
      }
      if (kg > 0 && service.pricePerKg != null && (service.maxKg == null || kg <= service.maxKg!)) {
        total += PricingService.computeKg(weightKg: kg, pricePerKg: service.pricePerKg!, minWeightKg: service.minKg, maxWeightKg: service.maxKg);
        hasLine = true;
      }
    }
    if (!hasLine) return null;
    DeliveryZone? zone;
    if (_zoneId != null) {
      for (final candidate in widget.pressing.deliveryZones) {
        if (candidate.id == _zoneId) {
          zone = candidate;
          break;
        }
      }
    }
    return total + (zone?.fee.round() ?? 0);
  }

  @override
  Widget build(BuildContext context) {
    final estimate = _estimate();
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Votre nom'))), const SizedBox(width: 10), Expanded(child: TextFormField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone (+237)', hintText: '6XX XX XX XX')))]),
            const SizedBox(height: 20),
            const Text('Ce que vous déposez', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            for (final service in widget.pressing.services) _OrderServiceRow(service: service, qty: _qty[service.id]!, kg: _kg[service.id]!, onChanged: () => setState(() {})),
            if (widget.pressing.deliveryZones.isNotEmpty) ...[
              const SizedBox(height: 18),
              const Text('Livraison', style: TextStyle(fontWeight: FontWeight.w900)),
              RadioListTile<String?>(contentPadding: EdgeInsets.zero, title: const Text('Retrait sur place (sans frais)'), value: null, groupValue: _zoneId, onChanged: (v) => setState(() => _zoneId = v)),
              for (final zone in widget.pressing.deliveryZones) RadioListTile<String?>(contentPadding: EdgeInsets.zero, title: Text('${zone.name} — ${PricingService.formatXaf(zone.fee)}'), subtitle: Text(zone.estimatedTime), value: zone.id, groupValue: _zoneId, onChanged: (v) => setState(() => _zoneId = v)),
            ],
            Container(margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFF2F0E8), borderRadius: BorderRadius.circular(16)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Estimation'), Text(estimate == null ? '—' : PricingService.formatXaf(estimate), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))])),
            const SizedBox(height: 5),
            Text('Estimation indicative : le prix final est calculé par le serveur. Paiement directement au pressing.', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            if (_errors.isNotEmpty) ...[const SizedBox(height: 14), for (final error in _errors) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('• $error', style: TextStyle(color: Colors.red.shade700, fontSize: 13)))],
            if (_message != null) ...[const SizedBox(height: 10), Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)), child: Text(_message!))],
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _sending ? null : _submit, child: Text(_sending ? 'Envoi…' : 'Envoyer ma commande'))),
          ]),
        ),
      ),
    );
  }
}

class _OrderServiceRow extends StatelessWidget {
  final PressingService service;
  final TextEditingController qty;
  final TextEditingController kg;
  final VoidCallback onChanged;
  const _OrderServiceRow({required this.service, required this.qty, required this.kg, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(service.name, style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 2), Text(PricingService.servicePriceLabel(service), style: TextStyle(fontSize: 11, color: Colors.grey.shade600))])), if (service.pricingType != PricingType.perKg) SizedBox(width: 72, child: TextField(controller: qty, keyboardType: TextInputType.number, onChanged: (_) => onChanged(), decoration: const InputDecoration(hintText: 'pcs', contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 11)))), if (service.pricingType == PricingType.both) const SizedBox(width: 7), if (service.pricingType != PricingType.perItem) SizedBox(width: 72, child: TextField(controller: kg, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => onChanged(), decoration: const InputDecoration(hintText: 'kg', contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 11))))]));
  }
}

class HourRow { final String label; final String value; const HourRow(this.label, this.value); }

List<HourRow> openingHoursRows(OpeningHours hours) {
  const labels = {WeekDay.monday: 'Lundi', WeekDay.tuesday: 'Mardi', WeekDay.wednesday: 'Mercredi', WeekDay.thursday: 'Jeudi', WeekDay.friday: 'Vendredi', WeekDay.saturday: 'Samedi', WeekDay.sunday: 'Dimanche'};
  String valueFor(WeekDay day) {
    final entry = hours[day];
    if (entry == null) return 'Fermé';
    String fr(String time) { final parts = time.split(':'); return '${parts.first}h${parts.length > 1 ? parts[1] : '00'}'; }
    return '${fr(entry.open)} – ${fr(entry.close)}';
  }
  final rows = <HourRow>[];
  String? currentLabel;
  String? currentValue;
  var count = 0;
  for (final day in WeekDay.values) {
    final label = labels[day]!;
    final value = valueFor(day);
    if (currentValue == value) {
      currentLabel = '$currentLabel – $label';
      count++;
    } else {
      if (currentLabel != null && currentValue != null) rows.add(HourRow(count > 1 ? currentLabel! : currentLabel!, currentValue!));
      currentLabel = label;
      currentValue = value;
      count = 1;
    }
  }
  if (currentLabel != null && currentValue != null) rows.add(HourRow(currentLabel!, currentValue!));
  return rows;
}
