import 'package:flutter_test/flutter_test.dart';
import 'package:light_app/main.dart';

void main() {
  testWidgets('LIGHT app starts', (WidgetTester tester) async {
    await tester.pumpWidget(const LightApp());
    expect(find.text('LIGHT'), findsOneWidget);
  });
}
